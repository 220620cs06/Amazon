import { renderOrderSummary } from "./checkout/orderSummary.js";
renderOrderSummary();
import{renderPaymentSummary} from"./checkout/paymentSummary.js";
import '../data/cart-oop.js';
renderPaymentSummary();